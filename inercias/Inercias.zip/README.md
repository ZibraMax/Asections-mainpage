# Inertiamoment
A geometrical properties calculator.

This is a small project, the objective is to calculate the area, centroid and inertia moment for shapes calculus.
The results obtained in the script would be used in deflexion and stress calculus.

I will appreciate your help for making this better

Thank You!

Hope you the best XMax: ZibraMax