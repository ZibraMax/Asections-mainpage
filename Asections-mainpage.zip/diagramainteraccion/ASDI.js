class ASDI{
	constructor() {

	}
}